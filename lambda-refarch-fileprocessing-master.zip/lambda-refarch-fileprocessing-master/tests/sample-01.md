# Introduction

This is a report that captures important information regarding an interview.

## Interview 1

The person I spoke with was elated.  They used words like 'fantastic', 'impressive', and 'ground breaking' to describe the new thing.

## Interview 2

The person I spoke with was really pleased.  They used words like 'wow', 'great', and 'cool' to describe the new thing.

# Summary

In short, the two people interviewed were very happy with the new thing.